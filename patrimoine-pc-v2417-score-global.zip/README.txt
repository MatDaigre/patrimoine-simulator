PATRIMOINE SIMULATOR — PATCH PC V2.4.17
COHÉRENCE SCORE GLOBAL / NOTE ANNUELLE / OBJECTIFS

SUR main :

REMPLACER :
- pc-visual-v230.js

AJOUTER :
- structural-score-v2417.js

CONSERVER tous les autres fichiers V2.4.

PROBLÈME :
Le score financier global ajoutait ou retirait jusqu'à 15 points selon la
performance récente des placements.

Un joueur financièrement solide pouvait donc perdre fortement en score
simplement parce que les marchés avaient baissé temporairement.

NOUVEAU SCORE GLOBAL :

22 % — Patrimoine
- patrimoine net rapporté au niveau de dépenses.

23 % — Résilience
- uniquement trésorerie + Livret.

20 % — Dettes
- taux d'endettement cohérent V2.4.14 ;
- pénalité supplémentaire pour dette coûteuse.

20 % — Efficacité
- capacité à dégager une marge mensuelle ;
- bonus modéré pour les versements automatiques effectivement programmés ;
- aucune influence directe de la volatilité boursière.

15 % — Qualité de vie
- bonheur.

CONSÉQUENCES :
- l'objectif « Équilibre durable » utilise automatiquement ce score ;
- la note annuelle et le score global évaluent désormais tous deux la
  qualité de gestion plutôt que la chance de marché ;
- les performances des placements restent visibles dans leur propre tableau,
  mais ne sont pas transformées en jugement de gestion à court terme.

Aucun rendement, patrimoine, versement, crédit, impôt ou trésorerie
n'est modifié.
